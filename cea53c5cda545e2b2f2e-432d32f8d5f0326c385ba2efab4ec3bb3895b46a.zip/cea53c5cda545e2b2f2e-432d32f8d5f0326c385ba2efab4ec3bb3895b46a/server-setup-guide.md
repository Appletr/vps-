Guide to set up a new VPS
=========================

This guide was written while setting up an Unbuntu VPS.
There may be some differences when setting up a different distro.

Initial steps as root
---------------------

Do some basic setup as the root user, which should mainly consist of
creating a new user in order to stop using the root user as soon as
possible.

### Change root password

If a VPS is provisioned with a root password, change it immediately:

    chgpasswd

### Configure skeleton files

Before creating the first user, it can be useful to edit the default
files copied to the user's home directory so that the configuration of
files like `.bashrc` only have to be done once, and not every time a
user is created.

    cd /etc/skel/
    vi .bashrc

Edit any other files as preferred.

#### Edit root user configs

It might be a good idea to edit `/root/.bashrc` as well, but it
shouldn't be very necessary since we shouldn't `su` as root very often.


### Create a new user

First, check if the sudo-group is an option in the file opened with the
`visudo` command. If it can, then create the user and add them to the
sudo-group all at once.

    adduser bwbaugh
    adduser bwbaugh sudo

Alternatively, create a new user with `adduser bwbaugh` then either:

-   If the sudo-group is listed in `visudo`, then the preferred option.

        usermod --append --groups sudo bwbaugh

-   Create an entry in `visudo` by copying the privilege entry for
    root.

From now on, we should be able to `ssh` and perform all other steps as
the new user using `sudo`.

Convenience packages
--------------------

-   Install `aptitude` in case it's not already.

        sudo apt-get install aptitude

-   Enable tab completion with `sudo`.

        sudo aptitude install bash-completion

    Afterwards, it will be necessary to exit and login for the changes
    to take effect.

-   There's some additional software that's useful to install.

        sudo aptitude install vim screen tmux

Configure the hostname
----------------------

-   Set to short name e.g., `prometheus`.

        sudo vim /etc/hostname
        sudo hostname prometheus

-   Set FQDN and add entry for host. For example, add an entry like:

        127.0.1.1       prometheus.bwbaugh.com prometheus

    by editing:

        sudo vim /etc/hosts

System time
-----------

-   Set the preferred timezone.

        sudo dpkg-reconfigure tzdata

-   Enable continuous time correction.
    Takes a while to take effect as it has to calculate drift
    statistics.

        sudo aptitude install ntp

Configure SSH
-------------

Use key-based authentication for your new user:

    ssh-copy-id user@host

NOTE: If you use `ControlMaster` in your `~/.ssh/config` then due to a
bug the above command will hang. Instead, you can use this alternative:

    cat ~/.ssh/id_rsa.pub | ssh user@host "mkdir -p ~/.ssh/ && cat - >> ~/.ssh/authorized_keys"

### Harden SSH

Edit the sshd configuration file:

    sudo vim /etc/ssh/sshd_config

and do the following:

-   Disable login as root.

        PermitRootLogin no

-   Only allow key-based logins.

        PasswordAuthentication no

-   Only allow whitelisted users to log in via SSH.

        AllowUsers bwbaugh

Then restart the sshd server to have the changes take effect:

    sudo service ssh restart

Also consider installing `fail2ban`.

Configure default editor
------------------------

If you use `vim` then you might want to update the default editor by
running the following with and without `sudo`:

    sudo update-alternatives --config editor

Forward logs
------------

Follow the [client install][logstash-forwarder] instructions.

[logstash-forwarder]: https://gist.github.com/bwbaugh/500da26b9e95208e41da#client-install


Install pip and virtualenv
--------------------------

These should be the only system-wide Python packages that need to be
installed.

1.  Install `pip` by following: <https://pip.pypa.io/en/latest/installing.html>
2.  Install virtualenv: `sudo pip install virtualenv`
3.  Optional: on EC2 it's useful to globally install:

        sudo pip install awscli
        complete -C aws_completer aws

Set up UFW as firewall
----------------------

Install and configure the UFW firewall.
Basic setup includes:

```bash
sudo aptitude install ufw
sudo ufw allow ssh
sudo ufw enable
```

### Redirect logs

It may be necessary to uncomment the last line of `sudo vim
/etc/rsyslog.d/20-ufw.conf` in order to have UFW logs go to its own
file. ([source](http://askubuntu.com/a/500702/381455))

Host intrusion detection system
-------------------------------

Follow this guide:
<https://www.digitalocean.com/community/tutorials/how-to-use-tripwire-to-detect-server-intrusions-on-an-ubuntu-vps>

Other useful info
-----------------

### Check versions

These commands can be useful when installing software whose setup steps
depend on the kernel or distro version.

-   Check kernel version:

        uname --all

-   Check version of Ubuntu:

        lsb_release --all
